﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WinCC.AD.gRPCService
{
    public class GroupModel
    {
        public string Name { get; set; }
        public int Bitn { get; set; }
    }
}
